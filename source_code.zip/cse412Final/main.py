import tkinter as tk
import psycopg2

#Players
#Chris Cano
#Abel Hadis
#Angel Flores
#David Arvizu

#connect to database
conn = psycopg2.connect(dbname="postgres", user="postgres", password="1233", host="localhost", port=5433)

#create cursor
cur = conn.cursor()

def add_window():

    add_win = tk.Toplevel()
    add_win.title('Add')
    add_win.geometry('400x400')

    label = tk.Label(add_win, text='You are in add')
    label.pack()

    def add1():
        #create and execute query
        cur.execute(
            """INSERT INTO players (playerID, name, age, goals_scored, teamID) VALUES (109, 'Chris Cano', 39, 0, 10);""")
        print("Player Added, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    def add2():
        # create and execute query
        cur.execute(
            """INSERT INTO players (playerID, name, age, goals_scored, teamID) VALUES (209, 'Abel Hadis', 25, 0, 20);""")
        print("Player Added, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    def add3():
        # create and execute query
        cur.execute(
            """INSERT INTO players (playerID, name, age, goals_scored, teamID) VALUES (309, 'Angel Flores', 39, 0, 30);""")
        print("Player Added, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    def add4():
        # create and execute query
        cur.execute(
            """INSERT INTO players (playerID, name, age, goals_scored, teamID) VALUES (409, 'David Arvizu', 39, 0, 40);""")
        print("Player Added, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    b1 = tk.Button(add_win, text='Add Chris Cano', command=add1)
    b2 = tk.Button(add_win, text='Add Abel Haddis', command=add2)
    b3 = tk.Button(add_win, text='Add Angel Flores', command=add3)
    b4 = tk.Button(add_win, text='Add David Arvizu', command=add4)
    cancel = tk.Button(add_win, text='cancel', command=add_win.destroy)

    b1.pack()
    b2.pack()
    b3.pack()
    b4.pack()
    cancel.pack()



def delete_window():
    delete_win = tk.Toplevel()
    delete_win.title('Delete')
    delete_win.geometry('400x400')

    label = tk.Label(delete_win, text='You are in delete')
    label.pack()

    def del1():
        # create and execute query
        cur.execute(
            """DELETE FROM players WHERE playerID = 109;""")
        print("Player Deleted, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    def del2():
        # create and execute query
        cur.execute(
            """DELETE FROM players WHERE playerID = 209;""")
        print("Player Deleted, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    def del3():
        # create and execute query
        cur.execute(
            """DELETE FROM players WHERE playerID = 309;""")
        print("Player Deleted, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    def del4():
        # create and execute query
        cur.execute(
            """DELETE FROM players WHERE playerID = 409;""")
        print("Player Deleted, Refresh Database to see changes")
        # Push changes - Note: this is in the event of Adding, deleting
        conn.commit()

    # Players
    # Chris Cano 109
    # Abel Hadis 209
    # Angel Flores 309
    # David Arvizu 409

    d1 = tk.Button(delete_win, text='Delete Player - Chris Cano', command=del1)
    d2 = tk.Button(delete_win, text='Delete Player - Abel Hadis', command=del2)
    d3 = tk.Button(delete_win, text='Delete Player - Angel Flores', command=del3)
    d4 = tk.Button(delete_win, text='Delete Player - David Arvizu', command=del4)
    cancel = tk.Button(delete_win, text='cancel', command=delete_win.destroy)

    d1.pack()
    d2.pack()
    d3.pack()
    d4.pack()
    cancel.pack()

def select_window():
    select_win = tk.Toplevel()
    select_win.title('Select')
    select_win.geometry('400x400')

    label = tk.Label(select_win, text='You are in select')
    label.pack()

    def sel1():
        #Create and Execute Query
        cur.execute("""SELECT name, age, goals_scored, teamID FROM players WHERE playerID = 301;""")
        queryOutput = cur.fetchall()
        print("Results:")
        print(queryOutput)

    def sel2():
        # Create and Execute Query
        cur.execute("""SELECT name, age, goals_scored, teamID FROM players WHERE playerID = 201;""")
        queryOutput = cur.fetchall()
        print("Results:")
        print(queryOutput)

    def sel3():
        # Create and Execute Query
        cur.execute("""SELECT name, age, goals_scored, teamID FROM players WHERE playerID = 101;""")
        queryOutput = cur.fetchall()
        print("Results:")
        print(queryOutput)

    def sel4():
        # Create and Execute Query
        cur.execute("""SELECT nation, coach, rank, goals_overall FROM teams WHERE teamID = 30;""")
        queryOutput = cur.fetchall()
        print("Results:")
        print(queryOutput)

    s1 = tk.Button(select_win, text='Select Player Stats - Lionel Messi', command=sel1)
    s2 = tk.Button(select_win, text='Select Player Stats - Christiano Ronaldo', command=sel2)
    s3 = tk.Button(select_win, text='Select Player Stats - Jordan Pickford', command=sel3)
    s4 = tk.Button(select_win, text='Select World Cup Winner', command=sel4)
    cancel = tk.Button(select_win, text='cancel', command=select_win.destroy)

    s1.pack()
    s2.pack()
    s3.pack()
    s4.pack()
    cancel.pack()

def update_window():
    update_win = tk.Toplevel()
    update_win.title('Update')
    update_win.geometry('400x400')

    label = tk.Label(update_win, text='You are in update')
    label.pack()

    def upd1():
        # Create and Execute Query
        cur.execute("""UPDATE players SET goals_scored = 5 WHERE playerID = 502;""")
        row_affected = cur.rowcount
        conn.commit()
        print(f"UPDATED query: {row_affected} row(s) updated.")

    def upd2():
        # Create and Execute Query
        cur.execute("""UPDATE players SET goals_scored = 10 WHERE playerID = 301;""")
        row_affected = cur.rowcount
        conn.commit()
        print(f"UPDATED query: {row_affected} row(s) updated.")

    def upd3():
        # Create and Execute Query
        cur.execute("""UPDATE players SET goals_scored = 1 WHERE playerID = 502;""")
        row_affected = cur.rowcount
        conn.commit()
        print(f"UPDATED query: {row_affected} row(s) updated.")

    def upd4():
        # Create and Execute Query
        cur.execute("""UPDATE players SET goals_scored = 4 WHERE playerID = 301;""")
        row_affected = cur.rowcount
        conn.commit()
        print(f"UPDATED query: {row_affected} row(s) updated.")

    u1 = tk.Button(update_win, text='Update Player Stats - Neymar - to 5 goals scored', command=upd1)
    u2 = tk.Button(update_win, text='Update Player Stats - Messi - to 10 goals scored', command=upd2)
    u3 = tk.Button(update_win, text='Update Player Stats - Neymar - to 1 goal scored', command=upd3)
    u4 = tk.Button(update_win, text='Update Player Stats - Messi - to 4 goals scored', command=upd4)
    cancel = tk.Button(update_win, text='cancel', command=update_win.destroy)

    u1.pack()
    u2.pack()
    u3.pack()
    u4.pack()
    cancel.pack()

def on_closing():
    # close cursor and connection when the application exits
    cur.close()
    conn.close()
    gui.destroy()

if __name__ == '__main__':
    gui = tk.Tk()
    gui.title('Database')
    gui.geometry('400x400')

    welcome_label = tk.Label(gui, text='Welcome to the Database Manager')
    welcome_label.pack()

    add_button = tk.Button(gui, text='add', command=add_window)
    delete_button = tk.Button(gui, text='delete', command=delete_window)
    select_button = tk.Button(gui, text='select', command=select_window)
    update_button = tk.Button(gui, text='update', command=update_window)

    add_button.pack()
    delete_button.pack()
    select_button.pack()
    update_button.pack()

    gui.protocol("WM_DELETE_WINDOW", on_closing)  # handle window close even
    gui.mainloop()
